from django.apps import AppConfig


class Birdapp657Config(AppConfig):
    name = 'birdapp657'
    default_auto_field = 'django.db.models.BigAutoField'
